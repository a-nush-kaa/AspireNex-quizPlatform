import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TakeQuiz = ({ match }) => {
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [score, setScore] = useState(null);

  useEffect(() => {
    const fetchQuiz = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/quiz/${match.params.id}`);
        setQuiz(response.data);
        setAnswers(new Array(response.data.questions.length).fill(null));
      } catch (error) {
        alert('Error fetching quiz');
      }
    };

    fetchQuiz();
  }, [match.params.id]);

  const handleAnswerChange = (questionIndex, value) => {
    const newAnswers = [...answers];
    newAnswers[questionIndex] = parseInt(value, 10);
    setAnswers(newAnswers);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post(`http://localhost:5000/quiz/${match.params.id}/submit`, { answers });
      setScore(response.data.score);
    } catch (error) {
      alert('Error submitting quiz');
    }
  };

  if (!quiz) {
    return <div>Loading...</div>;
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>{quiz.title}</h2>
      {quiz.questions.map((question, qIndex) => (
        <div key={qIndex}>
          <p>{question.question}</p>
          {question.options.map((option, oIndex) => (
            <label key={oIndex}>
              <input
                type="radio"
                name={`question-${qIndex}`}
                value={oIndex}
                checked={answers[qIndex] === oIndex}
                onChange={(e) => handleAnswerChange(qIndex, e.target.value)}
              />
              {option}
            </label>
          ))}
        </div>
      ))}
      <button type="submit">Submit</button>
      {score !== null && <p>Your score: {score}</p>}
    </form>
  );
};

export default TakeQuiz;
