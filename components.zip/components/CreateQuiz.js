import React, { useState } from 'react';
import axios from 'axios';

const CreateQuiz = () => {
  const [title, setTitle] = useState('');
  const [questions, setQuestions] = useState([
    { question: '', options: ['', '', '', ''], correctAnswer: 0 },
  ]);

  const handleQuestionChange = (index, key, value) => {
    const newQuestions = [...questions];
    newQuestions[index][key] = value;
    setQuestions(newQuestions);
  };

  const handleOptionChange = (questionIndex, optionIndex, value) => {
    const newQuestions = [...questions];
    newQuestions[questionIndex].options[optionIndex] = value;
    setQuestions(newQuestions);
  };

  const handleAddQuestion = () => {
    setQuestions([
      ...questions,
      { question: '', options: ['', '', '', ''], correctAnswer: 0 },
    ]);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.post('http://localhost:5000/quiz', { title, questions });
      alert('Quiz created successfully');
    } catch (error) {
      alert('Error creating quiz');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create Quiz</h2>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      {questions.map((question, qIndex) => (
        <div key={qIndex}>
          <input
            type="text"
            placeholder="Question"
            value={question.question}
            onChange={(e) => handleQuestionChange(qIndex, 'question', e.target.value)}
          />
          {question.options.map((option, oIndex) => (
            <input
              key={oIndex}
              type="text"
              placeholder={`Option ${oIndex + 1}`}
              value={option}
              onChange={(e) => handleOptionChange(qIndex, oIndex, e.target.value)}
            />
          ))}
          <select
            value={question.correctAnswer}
            onChange={(e) => handleQuestionChange(qIndex, 'correctAnswer', e.target.value)}
          >
            {question.options.map((option, oIndex) => (
              <option key={oIndex} value={oIndex}>
                {option}
              </option>
            ))}
          </select>
        </div>
      ))}
      <button type="button" onClick={handleAddQuestion}>Add Question</button>
      <button type="submit">Create Quiz</button>
    </form>
  );
};

export default CreateQuiz;
